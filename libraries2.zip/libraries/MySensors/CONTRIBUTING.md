<a href="https://www.mysensors.org/download/contributing">MySensors Code Contribution Guidelines</a>
